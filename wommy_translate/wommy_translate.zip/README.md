# Google Translate
This mod replaces all available text in the game with a poorly translated version.

Each dialog has been run through several languages in a translator before being returned back to English.

To make this mod, I used libretranslate, as Google Translate has rate limiting.