# ABSOLUTE CINEMA
This mod displays ABSOLUTE CINEMA whenever you bonk, get frozen or die.

This is my first mod, so don't expect it to function properly.